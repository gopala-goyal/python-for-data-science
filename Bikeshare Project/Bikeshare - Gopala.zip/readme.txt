Pandas library reference: https://pandas.pydata.org/pandas-docs/stable/reference/api/
Stackoverflow: 
https://stackoverflow.com/questions/35523635/extract-values-in-pandas-value-counts
https://stackoverflow.com/questions/60214194/error-in-reading-stock-data-datetimeproperties-object-has-no-attribute-week
https://stackoverflow.com/questions/25129144/pandas-return-hour-from-datetime-column-directly